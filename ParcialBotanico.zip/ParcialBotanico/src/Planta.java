/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public abstract class Planta {
    
    private String nombre;
    private String ubicacionJardin;
    private String climaProspero;

    public Planta(String nombre, String ubicacionJardin, String climaProspero) {
        this.nombre = nombre;
        this.ubicacionJardin = ubicacionJardin;
        this.climaProspero = climaProspero;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Planta{" + "nombre=" + nombre + ", ubicacionJardin=" + ubicacionJardin + ", climaProspero=" + climaProspero + '}';
    }


    
    
}
