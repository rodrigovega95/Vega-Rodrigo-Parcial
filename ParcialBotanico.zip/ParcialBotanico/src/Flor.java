/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Flor extends Planta {
    private TemporadaFlorecimiento TemporadaFlorecimiento;

    public Flor(TemporadaFlorecimiento TemporadaFlorecimiento, String nombre, String ubicacionJardin, String climaProspero) {
        super(nombre, ubicacionJardin, climaProspero);
        this.TemporadaFlorecimiento = TemporadaFlorecimiento;
    }

    @Override
    public String toString() {
        return "Flor{" + super.toString() +"TemporadaFlorecimiento=" + TemporadaFlorecimiento + '}';
    }

 
    


    

    
}
