
import java.util.ArrayList;

public class JardinBotanico {
    private ArrayList <Planta> plantas;

    public JardinBotanico() {
        this.plantas = new ArrayList<>();
    }


    
    public void agregarPlanta(Planta planta){
        if(this.plantas.contains(planta)){
            throw new PlantaDuplicadaException();
        }
        this.plantas.add(planta);
        
    }
    
    public void mostrarPlantas(){
        for(Planta planta : this.plantas){
            System.out.println(planta.toString());
        }
    }
    
    public void podarPlantas(){
        for(Planta planta : this.plantas){
            if(planta instanceof Podar podador ){
                podador.podar();
            }
            else{
                System.out.println(planta.getNombre() + " no puede ser podada");
            }
        }
    }
    
    
    
}
