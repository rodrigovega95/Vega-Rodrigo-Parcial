/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Arbol extends Planta implements Podar{
    private int alturaMax;

    public Arbol(int alturaMax, String nombre, String ubicacionJardin, String climaProspero) {
        super(nombre, ubicacionJardin, climaProspero);
        this.alturaMax = alturaMax;
    }

    @Override
    public String toString() {
        return "Arbol{" + super.toString() + "alturaMax=" + alturaMax + '}';
    }
    
    @Override
    public void podar(){
        System.out.println("Estoy siendo podado...");
    }
   
    
    
}
