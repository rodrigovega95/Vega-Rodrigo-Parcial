/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Arbusto extends Planta implements Podar {
    private int densidadFollaje;
    private static final int MINDENSIDAD=1;
    private static final int MAXDENSIDAD=10;

    public Arbusto(int densidadFollaje, String nombre, String ubicacionJardin, String climaProspero) {
        super(nombre, ubicacionJardin, climaProspero);
        this.densidadFollaje = densidadFollaje;
    }

    @Override
    public String toString() {
        return "Arbusto{" + super.toString() + "densidadFollaje=" + densidadFollaje + '}';
    }
    
    @Override
    public void podar(){
        System.out.println("Estoy siendo podada...");
    }


    
    
}
