public class test {


    public static void main(String[] args) {
        JardinBotanico jardinbotanico = new JardinBotanico();
        
        Flor flor = new Flor(TemporadaFlorecimiento.PRIMAVERA,"Orquidea","Sur-este","Calor");
        Arbol arbol = new Arbol(20,"Roble","Oeste","Todo clima");
        Arbusto arbusto = new Arbusto(5,"Helecho","Sur","Frío");
        
        try{
            jardinbotanico.agregarPlanta(flor);
            jardinbotanico.agregarPlanta(arbol);
            jardinbotanico.agregarPlanta(arbusto);
        }catch(PlantaDuplicadaException ex){
            System.out.println(ex);
        }
        
        
        
        jardinbotanico.mostrarPlantas();
        jardinbotanico.podarPlantas();
    }
    
    
}
